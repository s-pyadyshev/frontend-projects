"use strict";

(function() {
    Element.prototype.backgroundClipPolyfill = function () {
        var a = arguments[0],
            d = document,
            b = d.body,
            el = this;
      
        function hasBackgroundClip() {
          return b.style.webkitBackgroundClip != undefined;
        };
        
        function addAttributes(el, attributes) {
          for (var key in attributes) {
            el.setAttribute(key, attributes[key]);
          }
        }
        
        function createSvgElement(tagname) {
          return d.createElementNS('http://www.w3.org/2000/svg', tagname);
        }
        
        function createSVG() {
          var a = arguments[0],
              svg = createSvgElement('svg'),
              pattern = createSvgElement('pattern'),
              image = createSvgElement('image'),
              text = createSvgElement('text');
          
          addAttributes(pattern, {
            'id' : a.id,
            'patternUnits' : 'userSpaceOnUse',
            'width' : a.width,
            'height' : a.height
          });
          
          addAttributes(image, {
            'width' : a.width,
            'height' : a.height
          });
          image.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', a.url);
          
          addAttributes(text, {
            'x' : 0,
            'y' : 80,
            'class' : a.class,
            'style' : 'fill:url(#' + a.id + ');'
          });
          
          text.textContent = a.text;
            
          pattern.appendChild(image);
            
          svg.appendChild(pattern);
          svg.appendChild(text);
          
          return svg;
        };
        
        if (!hasBackgroundClip()) {
          var img = new Image();
          img.onload = function() {
            var svg = createSVG({
              'id' : a.patternID,
              'url' : a.patternURL,
              'class' : a.class,
              'width' : this.width,
              'height' : this.height,
              'text' : el.textContent
            });
            
            el.parentNode.replaceChild(svg, el);
          }
          img.src = a.patternURL;
        }
    };

    var gradientText = document.querySelector('.yellow-gradient'); 

    gradientText.backgroundClipPolyfill({
        'patternID' : 'mypattern',
        'patternURL' : 'img/yellow-gradient.png',
        'class' : 'myelement'
    });
})();
