$(document).ready(function() {
    @@include('partials/svg.js');
    document.querySelector('.svg-sprite').innerHTML = SVG_SPRITE;
});
