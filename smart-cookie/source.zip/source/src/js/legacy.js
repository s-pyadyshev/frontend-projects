@@include('legacy/classList.min.js'); // element.classList support
@@include('legacy/flexibility.js'); // flexbox support
@@include('legacy/html5shiv.min.js'); // enables use of HTML5 sectioning elements
@@include('legacy/respond.min.js'); // polyfill for min/max-width CSS3 Media Queries (for IE 6-8, and more)
@@include('legacy/selectivizr-min.js'); // emulates CSS3 pseudo-classes and attribute selectors in Internet Explorer 6-8
