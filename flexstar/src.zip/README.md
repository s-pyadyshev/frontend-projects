# flexstar front

$ yarn or npm i
$ gulp build
