<a href="https://s-pyadyshev.github.io/steinberger-html/build/index.html">Overview</a>
<br>
<a href="https://s-pyadyshev.github.io/steinberger-html/build/detail.html">Detail</a>

Project installation<br>
$ npm i<br>

Build<br>
$ gulp build<br>

Production build<br>
$ gulp build --minify<br>