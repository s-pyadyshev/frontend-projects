$(document).ready(function () {
  $(".section-header__image").addClass("is-loaded");
  $(".section-header__content").addClass("is-loaded");
});
